# Homework 1

* Sequential implementation of the **Mandelbrot** algorithm
* Parallel implementation using **MPI**
* Geometrical transformations of Images using the library **Pillow** of **Python**
